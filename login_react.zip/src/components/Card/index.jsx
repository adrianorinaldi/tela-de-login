import React from 'react';
import { FiThumbsUp } from 'react-icons/fi';
import { CardContainer, 
         Content,
         HasInfo,
         ImageBackground,
         PostInfo,
         UserInfo,
         UserPicture
       } from './styles';

const Card = () => {
  return (
    <CardContainer>
        <ImageBackground src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRXZz70UIEojEh3_sN3oDaOEmDPWtdSTqCQ58GbvDaiQT74yAB1vtOjsYuEe3NdHfxR5B0&usqp=CAU'/>
        <Content>
            <UserInfo>
                <UserPicture src='https://avatars.githubusercontent.com/u/11638931?v=4' />
                <div>
                    <h4>Adriano Rinaldi</h4>
                    <p>Há 8 min</p>
                </div>
            </UserInfo>
            <PostInfo>
                <h4>Projeto para curso de React.</h4>
                <p>Projeto feito com react.</p>
            </PostInfo>
            <HasInfo>
                <h4>#HTML #CSS #JAVASCRIPT #REACT</h4>
                <p>
                    <FiThumbsUp /> 18
                </p>
            </HasInfo>
        </Content>
    </CardContainer>
    )
}

export { Card };