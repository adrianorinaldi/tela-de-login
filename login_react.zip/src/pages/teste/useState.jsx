import { useState, useEffect } from 'react';

const Teste = () => {

    const [name, setName] = useState('Adriano');

    const handleChangeName = () => {
        setName(atual => atual === 'Adriano' ? 'é' : 'outro nome');
    }

    useEffect(() => {
      alert('testeeeee');

    }, [name]);

  return (
    <div>
        <p>
            {name}
        </p>
        <button onClick={handleChangeName}>Alterar</button>
    </div>
  )
}

export  default Teste ;