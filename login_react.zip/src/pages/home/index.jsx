import { Link, useNavigate } from 'react-router-dom';
import { Button } from '../../components/Button';
import { Header } from '../../components/Header';
import {Container, TextContent, Title, TitleHighLight } from './styles';
import Banner from '../../assets/images.jpg';

const Home = () => {

  const navigate = useNavigate();

  const handleClickSignIn = () => {
    navigate('/login');
  };

  return (<>
    <Header />
    <Container>
      <div>
        <Title>
          <TitleHighLight>
            Implemente
            <br />
            </TitleHighLight>
            o seu futuro global agora!
        </Title>
        <TextContent>
          Domine as tecnologias utilizadas pelas grandes empresas do mercado
          de inovação pelo mundo a fora.
        </TextContent>
        <Button title='Começar agora' variant='secondary' onCLick={handleClickSignIn} />
      </div>
      <div>
        <img src={Banner} alt='Imagem Principal' />
      </div>
    </Container>
    </>)

}
 
export default Home;